SELECT
    c.customer_id,
    c.customer_name,
    c.sales_channel,
    ROUND(SUM(p.amount)::numeric, 2) AS total_sales
FROM
    customers c
    INNER JOIN purchases p ON c.customer_id = p.customer_id
WHERE
    c.customer_id IN (
        SELECT
            customer_id
        FROM
            (
                SELECT
                    customer_id,
                    SUM(amount) AS total_sales
                FROM
                    purchases
                WHERE
                    DATE_PART('YEAR', purchase_date) IN (1998, 1999, 2001)
                GROUP BY
                    customer_id
                ORDER BY
                    total_sales DESC
                LIMIT 300
            ) AS top_customers
    )
    AND DATE_PART('YEAR', p.purchase_date) IN (1998, 1999, 2001)
GROUP BY
    c.customer_id,
    c.customer_name,
    c.sales_channel
ORDER BY
    total_sales DESC,
    c.sales_channel;